$ErrorActionPreference = 'Stop'
if (Get-Process -Name OrbitBrowser -ErrorAction SilentlyContinue) { throw 'Close Orbit Browser before uninstalling.' }
$installPath = Join-Path $env:LOCALAPPDATA 'MironBrowser\App'
if ([IO.Path]::GetFullPath($PSScriptRoot) -ne [IO.Path]::GetFullPath($installPath)) { throw 'Run uninstall from the installed Orbit app folder.' }
foreach ($path in @('Software\Classes\OrbitBrowser.Url','Software\Clients\StartMenuInternet\OrbitBrowser','Software\Microsoft\Windows\CurrentVersion\Uninstall\OrbitBrowser')) {
    [Microsoft.Win32.Registry]::CurrentUser.DeleteSubKeyTree($path,$false)
}
$registered = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey('Software\RegisteredApplications',$true)
if ($null -ne $registered) { try { $registered.DeleteValue('Orbit Browser',$false) } finally { $registered.Dispose() } }
foreach ($folder in @([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Programs'))) {
    $link = Join-Path $folder 'Orbit Browser.lnk'
    if (Test-Path -LiteralPath $link) { Remove-Item -LiteralPath $link -Force }
}
Remove-Item -LiteralPath $installPath -Recurse -Force
Start-Process 'ms-settings:defaultapps'
Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.MessageBox]::Show('Orbit removed. Choose another default browser in Windows. Your Orbit profile is preserved in LocalAppData\MironBrowser\Data.','Orbit Browser') | Out-Null
