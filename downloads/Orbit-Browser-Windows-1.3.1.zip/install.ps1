﻿$ErrorActionPreference = 'Stop'
if (Get-Process -Name OrbitBrowser -ErrorAction SilentlyContinue) { throw 'Close all Orbit Browser windows before installing this update.' }
# Release is precompiled; development checks run in CI.
if (!(Test-Path (Join-Path $PSScriptRoot 'portable\OrbitBrowser.exe'))) { & (Join-Path $PSScriptRoot 'build.ps1') }
$installPath = Join-Path $env:LOCALAPPDATA 'MironBrowser\App'
New-Item -ItemType Directory -Force $installPath | Out-Null
Copy-Item (Join-Path $PSScriptRoot 'portable\*') $installPath -Recurse -Force
foreach ($oldLogo in @('chatgpt-logo.png','chatgpt-logo.ico')) {
    $oldLogoPath = Join-Path $installPath $oldLogo
    if (Test-Path -LiteralPath $oldLogoPath) { Remove-Item -LiteralPath $oldLogoPath -Force }
}
$shellObject = New-Object -ComObject WScript.Shell
$desktopPath = [Environment]::GetFolderPath('Desktop')
$linkObject = $shellObject.CreateShortcut((Join-Path $desktopPath 'Orbit Browser.lnk'))
$linkObject.TargetPath = Join-Path $installPath 'OrbitBrowser.exe'
$linkObject.WorkingDirectory = $installPath
$linkObject.IconLocation = (Join-Path $installPath 'orbit.ico') + ',0'
$linkObject.Save()
$startMenuPath = [Environment]::GetFolderPath('Programs')
$startLink = $shellObject.CreateShortcut((Join-Path $startMenuPath 'Orbit Browser.lnk'))
$startLink.TargetPath = Join-Path $installPath 'OrbitBrowser.exe'
$startLink.WorkingDirectory = $installPath
$startLink.IconLocation = (Join-Path $installPath 'orbit.ico') + ',0'
$startLink.Save()
& (Join-Path $installPath 'register-browser.ps1') -AppPath $installPath
$uninstallKey = [Microsoft.Win32.Registry]::CurrentUser.CreateSubKey('Software\Microsoft\Windows\CurrentVersion\Uninstall\OrbitBrowser')
try {
    $uninstallKey.SetValue('DisplayName','Orbit Browser')
    $uninstallKey.SetValue('DisplayVersion','1.3.1')
    $uninstallKey.SetValue('DisplayIcon',(Join-Path $installPath 'OrbitBrowser.exe'))
    $uninstallKey.SetValue('InstallLocation',$installPath)
    $uninstallKey.SetValue('UninstallString','powershell.exe -NoProfile -ExecutionPolicy Bypass -File "' + (Join-Path $installPath 'uninstall.ps1') + '"')
} finally { $uninstallKey.Dispose() }
Write-Host 'Shortcuts created. To set default: Orbit menu > Default browser, then choose Orbit in Windows.' 
Start-Process -FilePath (Join-Path $installPath 'OrbitBrowser.exe')
