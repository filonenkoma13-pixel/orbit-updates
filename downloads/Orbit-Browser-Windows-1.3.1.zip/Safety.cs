using System;
using System.Net;
using System.Collections.Generic;
using System.Globalization;

static class OrbitSafety {
    public static string[] Reasons(Uri url) {
        var reasons=new List<string>();
        string host=url.IdnHost.ToLowerInvariant();IPAddress ip;
        if(IPAddress.TryParse(host.Trim('[',']'),out ip))reasons.Add("Вместо имени сайта указан IP-адрес.");
        if(host.Contains("xn--"))reasons.Add("Международное имя домена: буквы могут быть похожи на другой сайт.");
        if(host.Split('.').Length>=6)reasons.Add("В адресе слишком много вложенных поддоменов.");
        if(host.Length>80)reasons.Add("Необычно длинное имя сайта.");
        string unicode;
        try {unicode=new IdnMapping().GetUnicode(host);}catch {unicode=host;}
        foreach(string label in unicode.Split('.')) {
            bool latin=false,cyrillic=false;
            foreach(char c in label) {
                if((c>='a' && c<='z') || (c>='A' && c<='Z'))latin=true;
                if(c>='\u0400' && c<='\u052f')cyrillic=true;
            }
            if(latin && cyrillic) {reasons.Add("В имени смешаны латинские и кириллические буквы.");break;}
        }
        foreach(string brand in new string[]{"google.com","chatgpt.com","youtube.com","paypal.com","sberbank.ru","gosuslugi.ru"}) {
            if(host.StartsWith(brand+".",StringComparison.Ordinal)) {
                reasons.Add("Адрес начинается с известного сайта, но основной домен другой.");break;
            }
        }
        return reasons.ToArray();
    }
}
