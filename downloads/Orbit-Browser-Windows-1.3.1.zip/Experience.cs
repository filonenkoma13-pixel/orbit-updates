using System;
using System.IO;
using System.Drawing;
using System.Diagnostics;
using System.Collections.Generic;
using System.Windows.Forms;

partial class Browser {
    SplitContainer workHost;
    OrbitWorkspace workspace;
    bool focusView;
    readonly Dictionary<string,Tuple<DateTime,bool>> riskChoices=new Dictionary<string,Tuple<DateTime,bool>>();
    void InitializeExperience() {
        KeyPreview=true;
        workHost=new SplitContainer {Dock=DockStyle.Fill,BackColor=background,Size=new Size(Width-16,500),SplitterWidth=6};
        workHost.SplitterDistance=Math.Max(260,workHost.Width-300);workHost.Panel1MinSize=260;workHost.Panel2MinSize=260;workHost.Panel2Collapsed=true;
        rootLayout.Controls.Remove(web);workHost.Panel1.Controls.Add(web);rootLayout.Controls.Add(workHost,0,3);
    }
    void OpenAssistant(){var assistant=new Browser("https://miron-browser.floot.app/?assistant=1");assistant.Show();}
    void ToggleWork() {
        if(workspace==null){workspace=new OrbitWorkspace(data,CloseWork){Dock=DockStyle.Fill};workHost.Panel2.Controls.Add(workspace);}
        if(focusView)RestoreChrome();
        workHost.Panel2Collapsed=!workHost.Panel2Collapsed;
        if(!workHost.Panel2Collapsed)workHost.SplitterDistance=Math.Max(260,workHost.Width-300);
        UpdateWorkButton();
    }
    void CloseWork(){if(workHost==null)return;workHost.Panel2Collapsed=true;UpdateWorkButton();if(ready)web.Focus();}
    void UpdateWorkButton(){if(workButton!=null)workButton.Text=workHost.Panel2Collapsed?"Работа · F8":"Закрыть работу";}
    void ToggleFocus() {
        focusView=!focusView;
        rootLayout.RowStyles[0].Height=focusView?0:HeaderHeight;
        rootLayout.RowStyles[4].Height=focusView?0:StatusHeight;
        if(focusView)CloseWork();
    }
    protected override bool ProcessCmdKey(ref Message message,Keys keyData) {
        if(keyData==Keys.Escape && workHost!=null && !workHost.Panel2Collapsed){CloseWork();return true;}
        if(keyData==Keys.F8){ToggleWork();return true;}
        if(keyData==Keys.F11){ToggleFocus();return true;}
        if(keyData==(Keys.Control|Keys.L)){address.Focus();address.SelectAll();return true;}
        return base.ProcessCmdKey(ref message,keyData);
    }
    void ShowOrbitSplash() {
        var overlay=new Panel {Dock=DockStyle.Fill,BackColor=background};
        var logo=new PictureBox {Width=96,Height=96,SizeMode=PictureBoxSizeMode.Zoom,Cursor=Cursors.Hand};
        Image artwork=LoadOrbitArtwork();logo.Image=artwork;
        var caption=new Label {Text="ORBIT BROWSER",Height=36,Font=new Font("Segoe UI",18,FontStyle.Bold),ForeColor=accent,TextAlign=ContentAlignment.MiddleCenter};
        logo.Click+=delegate {OpenAssistant();};overlay.Controls.Add(logo);overlay.Controls.Add(caption);workHost.Panel1.Controls.Add(overlay);overlay.BringToFront();
        var elapsed=Stopwatch.StartNew();var animation=new System.Windows.Forms.Timer {Interval=16};
        Action position=delegate {
            double progress=Math.Max(0,Math.Min(1,(elapsed.Elapsed.TotalMilliseconds-250)/800));
            double ease=1-Math.Pow(1-progress,3);
            logo.Left=(overlay.ClientSize.Width-logo.Width)/2;
            int middle=Math.Max(28,(overlay.ClientSize.Height-logo.Height)/2-24);
            logo.Top=(int)(middle+(28-middle)*ease);
            caption.Left=0;caption.Width=overlay.ClientSize.Width;caption.Top=logo.Bottom+10;
        };
        EventHandler resize=delegate {position();};overlay.Resize+=resize;
        bool cleaned=false;
        Action cleanup=delegate {if(cleaned)return;cleaned=true;animation.Stop();animation.Dispose();elapsed.Stop();logo.Image=null;if(artwork!=null){artwork.Dispose();artwork=null;}};
        Action finish=delegate {cleanup();overlay.Dispose();};
        animation.Tick+=delegate {if(IsDisposed || overlay.IsDisposed){cleanup();return;}position();if(elapsed.ElapsedMilliseconds>=1450)finish();};
        overlay.Disposed+=delegate {cleanup();};
        position();animation.Start();
    }
    Image LoadOrbitArtwork(){try{return Image.FromFile(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"orbit-preview.png"));}catch{return null;}}
    DialogResult OrbitDialog(string title,string subtitle,string body,string action,bool cautious) {
        using(var dialog=new Form {Text="Orbit · "+title,Width=580,Height=550,BackColor=background,ForeColor=Color.White,Font=new Font("Segoe UI",11),
            StartPosition=FormStartPosition.CenterParent,FormBorderStyle=FormBorderStyle.FixedDialog,MaximizeBox=false,MinimizeBox=false,Icon=Icon,Opacity=0}) {
            var layout=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=5,Padding=new Padding(24)};
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute,88));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,48));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,32));layout.RowStyles.Add(new RowStyle(SizeType.Percent,100));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,46));
            var logoPanel=new Panel {Dock=DockStyle.Fill};var logo=new PictureBox {Width=72,Height=72,SizeMode=PictureBoxSizeMode.Zoom,Cursor=Cursors.Hand};
            var artwork=LoadOrbitArtwork();logo.Image=artwork;logo.Click+=delegate {OpenAssistant();};logoPanel.Controls.Add(logo);logoPanel.Resize+=delegate {logo.Left=(logoPanel.ClientSize.Width-logo.Width)/2;};layout.Controls.Add(logoPanel,0,0);
            layout.Controls.Add(new Label {Text=title,Dock=DockStyle.Fill,TextAlign=ContentAlignment.MiddleCenter,Font=new Font("Segoe UI",19,FontStyle.Bold)},0,1);
            var subheading=new Label {Text=title=="Orbit помощник"?"Щас проверю адрес на безопасность…":subtitle,Dock=DockStyle.Fill,TextAlign=ContentAlignment.MiddleCenter,ForeColor=accent};layout.Controls.Add(subheading,0,2);
            var text=new RichTextBox {Text=body,Dock=DockStyle.Fill,ReadOnly=true,DetectUrls=false,BackColor=background,ForeColor=Color.FromArgb(205,215,228),BorderStyle=BorderStyle.None,ScrollBars=RichTextBoxScrollBars.Vertical};layout.Controls.Add(text,0,3);
            var actions=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=cautious?2:1};
            var proceed=new Button {Text=action,Dock=DockStyle.Fill,BackColor=cautious?Color.FromArgb(42,54,72):accent,ForeColor=cautious?Color.White:background,FlatStyle=FlatStyle.Flat,DialogResult=DialogResult.OK};
            actions.Controls.Add(proceed,0,0);
            if(cautious){actions.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,50));actions.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,50));var back=new Button {Text="Вернуться",Dock=DockStyle.Fill,BackColor=accent,ForeColor=background,FlatStyle=FlatStyle.Flat,DialogResult=DialogResult.Cancel};actions.Controls.Add(back,1,0);dialog.AcceptButton=back;dialog.CancelButton=back;}else dialog.AcceptButton=proceed;
            layout.Controls.Add(actions,0,4);dialog.Controls.Add(layout);
            using(var fade=new System.Windows.Forms.Timer {Interval=30}) {
                fade.Tick+=delegate {dialog.Opacity=Math.Min(1,dialog.Opacity+0.12);if(dialog.Opacity==1){subheading.Text=subtitle;fade.Stop();}};dialog.Shown+=delegate {fade.Start();};
                try {return dialog.ShowDialog(this);}finally {logo.Image=null;if(artwork!=null)artwork.Dispose();}
            }
        }
    }
    bool riskPromptActive;
    bool AllowOrQueueRiskCheck(Uri url) {
        var reasons=OrbitSafety.Reasons(url);if(reasons.Length==0)return true;
        string key=url.GetLeftPart(UriPartial.Authority)+"|"+string.Join("|",reasons);Tuple<DateTime,bool> remembered;
        if(riskChoices.TryGetValue(key,out remembered) && remembered.Item1>DateTime.UtcNow)return remembered.Item2;
        if(!riskPromptActive) {
            riskPromptActive=true;
            BeginInvoke((Action)delegate {
                try {if(!IsDisposed && CheckSuspiciousAddress(url))web.CoreWebView2.Navigate(url.AbsoluteUri);}
                finally {riskPromptActive=false;}
            });
        }
        return false;
    }
    bool CheckSuspiciousAddress(Uri url) {
        var reasons=OrbitSafety.Reasons(url);if(reasons.Length==0)return true;
        string key=url.GetLeftPart(UriPartial.Authority)+"|"+string.Join("|",reasons);Tuple<DateTime,bool> remembered;
        if(riskChoices.TryGetValue(key,out remembered) && remembered.Item1>DateTime.UtcNow)return remembered.Item2;
        // Address heuristics only: no page content or private URLs are sent to another service.
        bool allow=OrbitDialog("Orbit помощник","Проверил адрес: есть подозрительные признаки",
            url.IdnHost+"\n\n• "+string.Join("\n\n• ",reasons)+"\n\nЭто локальная проверка адреса, а не проверка репутации сайта. Она не доказывает, что сайт опасен или безопасен. На сомнительном сайте не вводи пароль или карту.","Продолжить",true)==DialogResult.OK;
        if(riskChoices.Count>200)riskChoices.Clear();riskChoices[key]=Tuple.Create(DateTime.UtcNow.AddMinutes(30),allow);return allow;
    }
}
