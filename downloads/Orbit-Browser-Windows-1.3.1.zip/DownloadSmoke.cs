using System;
using System.IO;
using System.Text;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;
class DownloadSmoke {
    static int result=1,stage;static string folder;static WebView2 web;static Form form;
    [STAThread] static int Main(){
        folder=Path.Combine(Path.GetTempPath(),"OrbitDownloadTest-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(folder);
        Application.EnableVisualStyles();form=new Form {Width=700,Height=500,Text="Orbit download verification"};web=new WebView2 {Dock=DockStyle.Fill};form.Controls.Add(web);
        var timeout=new Timer {Interval=90000};timeout.Tick+=delegate {Console.Error.WriteLine("Download test timed out");form.Close();};timeout.Start();
        form.Shown+=async delegate {
            try {
                var environment=await CoreWebView2Environment.CreateAsync(null,Path.Combine(folder,"Profile"));await web.EnsureCoreWebView2Async(environment);
                web.CoreWebView2.DownloadStarting+=delegate(object sender,CoreWebView2DownloadStartingEventArgs e){
                    e.Handled=true;e.ResultFilePath=Path.Combine(folder,stage==0?"update.zip":"generated.txt");var operation=e.DownloadOperation;string path=e.ResultFilePath;
                    operation.StateChanged+=delegate {
                        try {
                            if(operation.State==CoreWebView2DownloadState.Interrupted)throw new Exception("Download interrupted: "+operation.InterruptReason);
                            if(operation.State!=CoreWebView2DownloadState.Completed)return;
                            byte[] bytes=File.ReadAllBytes(path);if(bytes.LongLength!=operation.BytesReceived)throw new Exception("Saved length mismatch");
                            if(stage==0){if(bytes.Length<100000||bytes[0]!=80||bytes[1]!=75)throw new Exception("Invalid update archive");Console.WriteLine("PASS: HTTPS Orbit update downloaded, "+bytes.Length+" bytes.");stage=1;web.CoreWebView2.NavigateToString("<html><body><script>setTimeout(function(){var a=document.createElement('a');a.href=URL.createObjectURL(new Blob(['Orbit download test'],{type:'text/plain'}));a.download='generated.txt';document.body.appendChild(a);a.click();},300);</script></body></html>");}
                            else {if(Encoding.UTF8.GetString(bytes)!="Orbit download test")throw new Exception("Generated file mismatch");Console.WriteLine("PASS: generated Blob file downloaded with exact content.");result=0;form.Close();}
                        }catch(Exception ex){Console.Error.WriteLine(ex);form.Close();}
                    };
                };
                web.CoreWebView2.Navigate("https://miron-browser.floot.app/_cdn/static/a4cbe524-a744-44a2-b87b-b5faa9cf932d-Orbit-Browser-Windows-1.3.0.zip");
            }catch(Exception ex){Console.Error.WriteLine(ex);form.Close();}
        };
        Application.Run(form);timeout.Dispose();return result;
    }
}
