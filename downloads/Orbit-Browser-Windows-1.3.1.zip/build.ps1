﻿param([switch]$Launch)
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$rootPath = $PSScriptRoot
$compilerPath = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (!(Test-Path $compilerPath)) { $compilerPath = Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe' }
if (!(Test-Path $compilerPath)) { throw '.NET Framework compiler not found. Install .NET Framework 4.8 from Microsoft.' }
$cachePath = Join-Path $rootPath '.build-cache'
$outPath = Join-Path $rootPath 'portable'
New-Item -ItemType Directory -Force $cachePath,$outPath | Out-Null
$packagePath = Join-Path $cachePath 'webview2.zip'
$extractPath = Join-Path $cachePath 'webview2'
$corePath = Join-Path $extractPath 'lib\net462\Microsoft.Web.WebView2.Core.dll'
if (!(Test-Path $corePath)) {
    Write-Host 'Downloading Microsoft WebView2 SDK from NuGet...'
    Invoke-WebRequest -UseBasicParsing -TimeoutSec 120 -Uri 'https://api.nuget.org/v3-flatcontainer/microsoft.web.webview2/1.0.3537.50/microsoft.web.webview2.1.0.3537.50.nupkg' -OutFile $packagePath
    Expand-Archive -LiteralPath $packagePath -DestinationPath $extractPath -Force
}
$formsPath = Join-Path $extractPath 'lib\net462\Microsoft.Web.WebView2.WinForms.dll'
Copy-Item $corePath,$formsPath $outPath -Force
foreach ($arch in @('win-x64','win-x86','win-arm64')) {
    $loaderPath = Join-Path $extractPath ('runtimes\' + $arch + '\native\WebView2Loader.dll')
    if (Test-Path $loaderPath) {
        $destinationPath = Join-Path $outPath ('runtimes\' + $arch + '\native')
        New-Item -ItemType Directory -Force $destinationPath | Out-Null
        Copy-Item $loaderPath $destinationPath -Force
    }
}
$arguments = @('/nologo','/target:winexe','/platform:anycpu','/optimize+','/utf8output',('/win32icon:' + (Join-Path $rootPath 'orbit.ico')),('/out:' + (Join-Path $outPath 'OrbitBrowser.exe')),('/reference:' + $corePath),('/reference:' + $formsPath),'/reference:System.dll','/reference:System.Security.dll','/reference:System.Core.dll','/reference:System.Drawing.dll','/reference:System.Windows.Forms.dll','/reference:System.Web.Extensions.dll',(Join-Path $rootPath 'Browser.cs'),(Join-Path $rootPath 'Release.cs'),(Join-Path $rootPath 'Safety.cs'),(Join-Path $rootPath 'Workspace.cs'),(Join-Path $rootPath 'Experience.cs'),(Join-Path $rootPath 'Downloads.cs'))
Write-Host 'Compiling Orbit Browser...'
& $compilerPath @arguments
if ($LASTEXITCODE -ne 0) { throw 'Compilation failed. Copy the error text for troubleshooting.' }
Copy-Item (Join-Path $rootPath 'OrbitBrowser.exe.config') $outPath -Force
Copy-Item (Join-Path $rootPath 'orbit.ico') $outPath -Force
Copy-Item (Join-Path $rootPath 'orbit-preview.png'),(Join-Path $rootPath 'register-browser.ps1'),(Join-Path $rootPath 'uninstall.ps1') $outPath -Force
Write-Host ('Ready: ' + (Join-Path $outPath 'OrbitBrowser.exe'))
if ($Launch) { Start-Process -FilePath (Join-Path $outPath 'OrbitBrowser.exe') }
