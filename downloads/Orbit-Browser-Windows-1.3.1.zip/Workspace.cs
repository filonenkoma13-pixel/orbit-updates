using System;
using System.IO;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Collections.Generic;
using System.Web.Script.Serialization;

class OrbitTask {
    public string Text {get;set;}
    public bool Done {get;set;}
    public override string ToString(){return Text;}
}
class OrbitWorkState {
    public string Notes {get;set;}
    public List<OrbitTask> Tasks {get;set;}
}
class OrbitWorkspace : UserControl {
    readonly CheckedListBox tasks=new CheckedListBox();
    readonly TextBox notes=new TextBox();
    readonly Label hint=new Label(),clock=new Label();
    readonly ComboBox duration=new ComboBox();
    readonly Button start=new Button();
    readonly System.Windows.Forms.Timer saveTimer=new System.Windows.Forms.Timer {Interval=500};
    readonly System.Windows.Forms.Timer focusTimer=new System.Windows.Forms.Timer {Interval=500};
    readonly string storage;
    bool loaded,storageAvailable=true,running,dirty;
    string diskDigest;
    int remaining=25*60;
    DateTime ends;
    public OrbitWorkspace(string directory,Action close) {
        storage=Path.Combine(directory,"workspace.dpapi");BackColor=Color.FromArgb(21,32,49);ForeColor=Color.White;Font=new Font("Segoe UI",10);
        var grid=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=8,Padding=new Padding(12)};
        foreach(int height in new int[]{44,30})grid.RowStyles.Add(new RowStyle(SizeType.Absolute,height));
        grid.RowStyles.Add(new RowStyle(SizeType.Percent,40));grid.RowStyles.Add(new RowStyle(SizeType.Absolute,38));
        grid.RowStyles.Add(new RowStyle(SizeType.Absolute,28));grid.RowStyles.Add(new RowStyle(SizeType.Percent,60));
        grid.RowStyles.Add(new RowStyle(SizeType.Absolute,58));grid.RowStyles.Add(new RowStyle(SizeType.Absolute,40));
        var heading=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=2,RowCount=1,Margin=Padding.Empty};
        heading.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));heading.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,88));heading.RowStyles.Add(new RowStyle(SizeType.Percent,100));
        heading.Controls.Add(new Label {Text="Рабочее место",Dock=DockStyle.Fill,TextAlign=ContentAlignment.MiddleLeft,Font=new Font("Segoe UI",11,FontStyle.Bold)},0,0);
        var closeButton=new Button {Text="Закрыть",Dock=DockStyle.Fill,FlatStyle=FlatStyle.Flat,BackColor=Color.FromArgb(31,43,61),ForeColor=Color.FromArgb(101,229,204),Font=new Font("Segoe UI",9),Margin=new Padding(2,4,0,4)};
        closeButton.FlatAppearance.BorderSize=0;closeButton.Click+=delegate {close();};heading.Controls.Add(closeButton,1,0);grid.Controls.Add(heading,0,0);
        var taskInput=new TextBox {Dock=DockStyle.Fill,MaxLength=200};grid.Controls.Add(taskInput,0,1);
        tasks.Dock=DockStyle.Fill;tasks.CheckOnClick=true;tasks.BackColor=BackColor;tasks.ForeColor=ForeColor;tasks.BorderStyle=BorderStyle.None;tasks.HorizontalScrollbar=true;grid.Controls.Add(tasks,0,2);
        var actions=new FlowLayoutPanel {Dock=DockStyle.Fill,WrapContents=false};
        var add=new Button {Text="+ Задача",Width=92,Height=30};
        Action addTask=delegate {
            string value=taskInput.Text.Trim();if(value.Length==0)return;
            if(tasks.Items.Count>=60){hint.Text="Можно сохранить до 60 задач.";return;}
            tasks.Items.Add(new OrbitTask {Text=value});taskInput.Clear();QueueSave();
        };
        add.Click+=delegate {addTask();};taskInput.KeyDown+=delegate(object s,KeyEventArgs e){if(e.KeyCode==Keys.Enter){e.SuppressKeyPress=true;addTask();}};
        var clear=new Button {Text="Убрать готовые",Width=128,Height=30};clear.Click+=delegate {for(int i=tasks.Items.Count-1;i>=0;i--)if(tasks.GetItemChecked(i))tasks.Items.RemoveAt(i);QueueSave();};
        actions.Controls.Add(add);actions.Controls.Add(clear);grid.Controls.Add(actions,0,3);
        grid.Controls.Add(new Label {Text="Заметки",Dock=DockStyle.Fill},0,4);
        notes.Dock=DockStyle.Fill;notes.Multiline=true;notes.AcceptsReturn=true;notes.ScrollBars=ScrollBars.Vertical;notes.MaxLength=20000;notes.BackColor=Color.FromArgb(31,43,61);notes.ForeColor=Color.White;grid.Controls.Add(notes,0,5);
        var focus=new FlowLayoutPanel {Dock=DockStyle.Fill,WrapContents=false};
        duration.DropDownStyle=ComboBoxStyle.DropDownList;duration.Width=68;duration.Items.AddRange(new object[]{"25 мин","50 мин"});duration.SelectedIndex=0;
        clock.Text="25:00";clock.Width=64;clock.Height=32;clock.TextAlign=ContentAlignment.MiddleCenter;clock.ForeColor=Color.FromArgb(101,229,204);
        start.Text="Старт";start.Width=70;start.Height=30;start.Click+=delegate {if(running){remaining=Math.Max(0,(int)Math.Ceiling((ends-DateTime.UtcNow).TotalSeconds));running=false;start.Text="Старт";}else{if(remaining<=0)remaining=(duration.SelectedIndex==0?25:50)*60;ends=DateTime.UtcNow.AddSeconds(remaining);running=true;start.Text="Пауза";}duration.Enabled=!running;};
        duration.SelectedIndexChanged+=delegate {if(!running){remaining=(duration.SelectedIndex==0?25:50)*60;UpdateClock();}};
        focus.Controls.Add(duration);focus.Controls.Add(clock);focus.Controls.Add(start);grid.Controls.Add(focus,0,6);
        hint.Text="Заметки и задачи хранятся локально с шифрованием Windows.";hint.Dock=DockStyle.Fill;hint.Font=new Font("Segoe UI",8);grid.Controls.Add(hint,0,7);Controls.Add(grid);
        LoadState();loaded=true;
        notes.TextChanged+=delegate {QueueSave();};tasks.ItemCheck+=delegate {if(loaded && IsHandleCreated)BeginInvoke((Action)QueueSave);};
        saveTimer.Tick+=delegate {saveTimer.Stop();SaveState();};
        focusTimer.Tick+=delegate {if(running){remaining=Math.Max(0,(int)Math.Ceiling((ends-DateTime.UtcNow).TotalSeconds));if(remaining==0){running=false;start.Text="Старт";duration.Enabled=true;hint.Text="Сессия завершена. Сделай небольшой перерыв.";}UpdateClock();}};focusTimer.Start();
    }
    void UpdateClock(){clock.Text=(remaining/60).ToString("00")+":"+(remaining%60).ToString("00");}
    void QueueSave(){if(!loaded || IsDisposed)return;dirty=true;saveTimer.Stop();saveTimer.Start();}
    void LoadState() {
        if(!File.Exists(storage))return;
        try {
            var encrypted=File.ReadAllBytes(storage);if(encrypted.Length>262144)throw new InvalidDataException();
            diskDigest=Digest(encrypted);
            var bytes=ProtectedData.Unprotect(encrypted,null,DataProtectionScope.CurrentUser);
            var state=new JavaScriptSerializer().Deserialize<OrbitWorkState>(Encoding.UTF8.GetString(bytes));
            if(state==null || (state.Notes!=null && state.Notes.Length>20000) || state.Tasks==null || state.Tasks.Count>60)throw new InvalidDataException();
            foreach(var task in state.Tasks)if(task==null || task.Text==null || task.Text.Length>200)throw new InvalidDataException();
            notes.Text=state.Notes??"";foreach(var task in state.Tasks)tasks.Items.Add(task,task.Done);
        }catch {storageAvailable=false;hint.Text="Не удалось прочитать заметки. Старый файл сохранён; изменения не записываются.";}
    }
    void SaveState() {
        if(!storageAvailable || !dirty)return;
        try {
            string current=File.Exists(storage)?Digest(File.ReadAllBytes(storage)):null;
            if(current!=diskDigest){hint.Text="Заметки изменены в другом окне. Перезапусти это окно браузера.";return;}
            var state=new OrbitWorkState {Notes=notes.Text,Tasks=new List<OrbitTask>()};
            for(int i=0;i<tasks.Items.Count;i++)state.Tasks.Add(new OrbitTask {Text=((OrbitTask)tasks.Items[i]).Text,Done=tasks.GetItemChecked(i)});
            var bytes=Encoding.UTF8.GetBytes(new JavaScriptSerializer().Serialize(state));
            var protectedBytes=ProtectedData.Protect(bytes,null,DataProtectionScope.CurrentUser);
            string temporary=storage+".tmp";File.WriteAllBytes(temporary,protectedBytes);
            if(File.Exists(storage))File.Replace(temporary,storage,null);else File.Move(temporary,storage);
            diskDigest=Digest(protectedBytes);dirty=false;
        }catch {hint.Text="Не удалось сохранить заметки. Проверь свободное место и доступ к папке.";}
    }
    static string Digest(byte[] bytes){using(var hash=SHA256.Create())return Convert.ToBase64String(hash.ComputeHash(bytes));}
    protected override void Dispose(bool disposing) {
        if(disposing){if(loaded)SaveState();saveTimer.Dispose();focusTimer.Dispose();}base.Dispose(disposing);
    }
}
