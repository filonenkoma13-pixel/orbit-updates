$ErrorActionPreference = 'Stop'
$compilerPath = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (!(Test-Path $compilerPath)) { $compilerPath = Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe' }
foreach ($name in @('build.ps1','install.ps1','register-browser.ps1','uninstall.ps1')) {
    $tokens = $null; $errors = $null
    [System.Management.Automation.Language.Parser]::ParseFile((Join-Path $PSScriptRoot $name),[ref]$tokens,[ref]$errors) | Out-Null
    if ($errors.Count -gt 0) { throw ($errors | Out-String) }
}
$testPath = Join-Path $env:TEMP ('OrbitReleaseCheck-' + [Guid]::NewGuid().ToString() + '.exe')
try {
    & $compilerPath '/nologo' '/target:exe' ('/out:'+$testPath) '/reference:System.dll' '/reference:System.Core.dll' '/reference:System.Web.Extensions.dll' (Join-Path $PSScriptRoot 'Release.cs') (Join-Path $PSScriptRoot 'ReleaseValidation.cs') (Join-Path $PSScriptRoot 'Safety.cs')
    if ($LASTEXITCODE -ne 0) { throw 'Release test compilation failed.' }
    & $testPath
    if ($LASTEXITCODE -ne 0) { throw 'Release tests failed.' }
} finally { if (Test-Path $testPath) { Remove-Item $testPath -Force } }
