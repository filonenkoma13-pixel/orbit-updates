@echo off
cd /d "%~dp0"
if exist "%~dp0portable\OrbitBrowser.exe" (
    start "Orbit Browser" "%~dp0portable\OrbitBrowser.exe"
) else (
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0build.ps1" -Launch
)
