using System;
using System.IO;
class ReleaseValidation {
    static void Reject(ReleaseInfo release) {
        try {OrbitRelease.Validate(release);}catch(InvalidDataException){return;}
        throw new Exception("Unsafe release accepted");
    }
    static int Main() {
        var current=new ReleaseInfo {platform="windows",version=OrbitRelease.VersionText,notes=new string[0]};
        if(OrbitRelease.IsNewer(OrbitRelease.Validate(current)))throw new Exception("Current version marked new");
        current.version=OrbitRelease.VersionText+".0";
        if(OrbitRelease.IsNewer(current))throw new Exception("Same four-part version marked new");
        current.version="2.0.0";
        if(!OrbitRelease.IsNewer(current))throw new Exception("New version not detected");
        current.version="1.0.0";
        if(OrbitRelease.IsNewer(current))throw new Exception("Downgrade offered");
        Reject(new ReleaseInfo {platform="android",version="2.0"});
        Reject(new ReleaseInfo {platform="windows",version="invalid"});
        Reject(new ReleaseInfo {platform="windows",version="2.0",downloadUrl="javascript:alert(1)"});
        Reject(new ReleaseInfo {platform="windows",version="2.0",downloadUrl="https://user:pass@example.com/release.zip"});
        Reject(new ReleaseInfo {platform="windows",version="2.0",notes=new string[]{new string('x',401)}});
        if(OrbitAddress.NormalizeLaunchUrl("https://example.com/a?q=1")!="https://example.com/a?q=1")throw new Exception("HTTPS link changed");
        if(OrbitAddress.NormalizeLaunchUrl("http://example.com/a")!="https://example.com/a")throw new Exception("HTTP not upgraded");
        foreach(var input in new string[]{"javascript:alert(1)","file:///C:/a.html","https://user:pass@example.com/","--proxy-server=x"})
            if(OrbitAddress.NormalizeLaunchUrl(input)!=null)throw new Exception("Unsafe activation accepted");
        if(OrbitSafety.Reasons(new Uri("https://example.com/a")).Length!=0)throw new Exception("Ordinary domain warned");
        foreach(var url in new string[]{"https://127.0.0.1/","https://xn--e1afmkfd.xn--p1ai/","https://google.com.attacker.example/","https://a.b.c.d.e.example.com/"})
            if(OrbitSafety.Reasons(new Uri(url)).Length==0)throw new Exception("Suspicious address missed");
        Console.WriteLine("Release validation passed.");return 0;
    }
}
