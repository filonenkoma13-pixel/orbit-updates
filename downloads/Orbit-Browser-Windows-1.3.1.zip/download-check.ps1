$ErrorActionPreference = 'Stop'
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$output = Join-Path $PSScriptRoot 'portable\DownloadSmoke.exe'
$arguments = @('/nologo','/target:exe','/platform:anycpu',('/out:'+$output),'/reference:System.dll','/reference:System.Core.dll','/reference:System.Windows.Forms.dll','/reference:System.Drawing.dll',('/reference:'+(Join-Path $PSScriptRoot 'portable\Microsoft.Web.WebView2.Core.dll')),('/reference:'+(Join-Path $PSScriptRoot 'portable\Microsoft.Web.WebView2.WinForms.dll')),(Join-Path $PSScriptRoot 'DownloadSmoke.cs'))
& $compiler @arguments
if ($LASTEXITCODE -ne 0) { throw 'Download test compilation failed' }
try {
    & $output
    if ($LASTEXITCODE -ne 0) { throw 'Live WebView2 download test failed' }
} finally { Remove-Item $output -Force -ErrorAction SilentlyContinue }
