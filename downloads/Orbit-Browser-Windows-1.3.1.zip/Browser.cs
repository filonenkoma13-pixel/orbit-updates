﻿using System;
using System.IO;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Web.Script.Serialization;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

class Preferences {
    public string Proxy { get; set; }
    public string DisplayName { get; set; }
    public List<string> Bookmarks { get; set; }
    public Preferences() { Proxy=""; Bookmarks=new List<string>(); }
}
partial class Browser : Form {
    readonly Color background=Color.FromArgb(16,24,40), accent=Color.FromArgb(101,229,204);
    readonly WebView2 web=new WebView2();
    readonly TextBox address=new TextBox();
    readonly Label status=new Label();
    readonly ProgressBar loading=new ProgressBar();
    readonly string data=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"MironBrowser","Data");
    Preferences prefs=new Preferences();
    bool ready, checkingUpdates;
    readonly string initialUrl;
    readonly bool firstInstallation;
    TableLayoutPanel rootLayout;
    const int HeaderHeight=40, NavigationHeight=38, LoadingHeight=2, StatusHeight=20;
    Button workButton;
    [STAThread] static void Main(string[] args) {
        Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
        try { Application.Run(new Browser(args.Length>0?args[0]:null)); }
        catch(Exception e) { MessageBox.Show("Не удалось запустить браузер.\n"+e.Message,"Orbit Browser"); }
    }
    public Browser(string launchUrl) {
        initialUrl=OrbitAddress.NormalizeLaunchUrl(launchUrl);
        firstInstallation=!Directory.Exists(Path.Combine(data,"Profile"));
        Directory.CreateDirectory(data);
        Icon=Icon.ExtractAssociatedIcon(Application.ExecutablePath);
        try { prefs=new JavaScriptSerializer().Deserialize<Preferences>(File.ReadAllText(Path.Combine(data,"settings.json"))) ?? new Preferences(); } catch { }
        if(prefs.Bookmarks==null)prefs.Bookmarks=new List<string>();
        prefs.Proxy="";
        Text="Orbit Browser"; Width=1180;Height=800;MinimumSize=new Size(660,460);StartPosition=FormStartPosition.CenterScreen;BackColor=background;Font=new Font("Segoe UI",10);
        var layout=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=5,BackColor=background,Padding=new Padding(4)};
        rootLayout=layout;
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute,HeaderHeight));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,NavigationHeight));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,LoadingHeight));layout.RowStyles.Add(new RowStyle(SizeType.Percent,100));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,StatusHeight));
        var header=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=3,RowCount=1,Margin=Padding.Empty};header.RowStyles.Add(new RowStyle(SizeType.Percent,100));header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,110));header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,150));
        var brand=new FlowLayoutPanel {Dock=DockStyle.Fill,WrapContents=false,Margin=Padding.Empty,Cursor=Cursors.Hand};
        var brandLogo=new PictureBox {Width=24,Height=24,SizeMode=PictureBoxSizeMode.Zoom,Image=LoadOrbitArtwork(),Cursor=Cursors.Hand,Margin=new Padding(0,0,6,0)};
        var brandName=new Label {Text="ORBIT  /  BROWSER",AutoSize=true,ForeColor=accent,Font=new Font("Segoe UI",11,FontStyle.Bold),Cursor=Cursors.Hand};
        brandLogo.Click+=delegate {OpenAssistant();};brandName.Click+=delegate {OpenAssistant();};brand.Controls.Add(brandLogo);brand.Controls.Add(brandName);header.Controls.Add(brand,0,0);
        FormClosed+=delegate {if(brandLogo.Image!=null){brandLogo.Image.Dispose();brandLogo.Image=null;}};
        header.Controls.Add(Btn("Обновления",delegate {Go("https://miron-browser.floot.app/updates");}),1,0);workButton=Btn("Работа · F8",ToggleWork);header.Controls.Add(workButton,2,0);
        layout.Controls.Add(header,0,0);
        var nav=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=7,Margin=Padding.Empty};
        for(int i=0;i<4;i++)nav.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,36));
        nav.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));nav.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,44));nav.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,36));
        nav.Controls.Add(Btn("‹",delegate {if(ready && web.CanGoBack)web.GoBack();}),0,0);
        nav.Controls.Add(Btn("›",delegate {if(ready && web.CanGoForward)web.GoForward();}),1,0);
        nav.Controls.Add(Btn("↻",delegate {if(ready)web.Reload();}),2,0);nav.Controls.Add(Btn("⌂",Home),3,0);
        address.Dock=DockStyle.Fill;address.BackColor=Color.FromArgb(31,43,61);address.ForeColor=Color.White;address.BorderStyle=BorderStyle.FixedSingle;address.Font=new Font("Segoe UI",11);address.Margin=new Padding(4,5,4,3);
        address.KeyDown+=delegate(object s,KeyEventArgs e){if(e.KeyCode==Keys.Enter){e.SuppressKeyPress=true;Go(address.Text);}};
        nav.Controls.Add(address,4,0);nav.Controls.Add(Btn("→",delegate {Go(address.Text);}),5,0);nav.Controls.Add(Btn("⋮",Menu),6,0);layout.Controls.Add(nav,0,1);
        loading.Margin=Padding.Empty;loading.Dock=DockStyle.Fill;loading.Style=ProgressBarStyle.Marquee;loading.Visible=false;layout.Controls.Add(loading,0,2);
        web.Margin=Padding.Empty;web.Dock=DockStyle.Fill;web.DefaultBackgroundColor=background;layout.Controls.Add(web,0,3);
        status.Margin=Padding.Empty;status.Font=new Font("Segoe UI",8);status.AutoEllipsis=true;status.Dock=DockStyle.Fill;status.ForeColor=Color.Silver;status.TextAlign=ContentAlignment.MiddleLeft;status.Text="Загрузка движка…";layout.Controls.Add(status,0,4);Controls.Add(layout);
        InitializeExperience();
        Shown+=async delegate {
            await Initialize();
            if(!ready || IsDisposed)return;
            string seenPath=Path.Combine(data,"release-seen.txt"),seen="";
            try {seen=File.ReadAllText(seenPath).Trim();}catch { }
            // Opening a link takes priority; show the welcome on the next normal launch.
            if(initialUrl==null && seen!=OrbitRelease.VersionText) {
                if(ShowReleaseNotes(seen.Length==0 && firstInstallation))try {File.WriteAllText(seenPath,OrbitRelease.VersionText);}catch { }
            }
            if(initialUrl==null)ShowOrbitSplash();
            await CheckUpdates(false);
        };
    }
    Button Btn(string label,Action action) {
        var b=new Button {Text=label,Dock=DockStyle.Fill,FlatStyle=FlatStyle.Flat,BackColor=Color.FromArgb(25,37,54),ForeColor=accent,Margin=new Padding(2),Padding=Padding.Empty,Font=new Font("Segoe UI",9),TextAlign=ContentAlignment.MiddleCenter,UseCompatibleTextRendering=false,AutoSize=false};
        b.FlatAppearance.BorderSize=0;b.Click+=delegate {action();};return b;
    }
    async System.Threading.Tasks.Task Initialize() {
        try {
            var options=new CoreWebView2EnvironmentOptions();
            // Fixed localhost only: never accept arbitrary command-line browser flags.
            var environment=await CoreWebView2Environment.CreateAsync(null,Path.Combine(data,"Profile"),options);
            await web.EnsureCoreWebView2Async(environment);
            web.CoreWebView2.Settings.AreDevToolsEnabled=false;
            web.CoreWebView2.Settings.IsGeneralAutofillEnabled=false;
            web.CoreWebView2.Settings.IsPasswordAutosaveEnabled=false;
            web.CoreWebView2.Settings.AreHostObjectsAllowed=false;
            web.CoreWebView2.Settings.IsWebMessageEnabled=false;
            web.CoreWebView2.NavigationStarting+=delegate(object sender,CoreWebView2NavigationStartingEventArgs e){
                Uri u;
                if(e.Uri!="about:blank" && (!Uri.TryCreate(e.Uri,UriKind.Absolute,out u) || u.Scheme!="https" || !string.IsNullOrEmpty(u.UserInfo))){e.Cancel=true;status.Text="Разрешены адреса HTTPS.";return;}
                if(e.Uri!="about:blank" && !AllowOrQueueRiskCheck(new Uri(e.Uri))) {e.Cancel=true;loading.Visible=false;return;}
                loading.Visible=true;
            };
            web.CoreWebView2.NavigationCompleted+=delegate(object sender,CoreWebView2NavigationCompletedEventArgs e){loading.Visible=false;if(!e.IsSuccess)status.Text="Сайт не открылся: "+e.WebErrorStatus+". Проверь адрес и подключение.";else RouteLabel();};
            web.CoreWebView2.SourceChanged+=delegate {if(!address.Focused)address.Text=web.Source==null || web.Source.ToString()=="about:blank"?"":web.Source.ToString();};
            web.CoreWebView2.DocumentTitleChanged+=delegate {Text="Orbit Browser — "+web.CoreWebView2.DocumentTitle;};
            web.CoreWebView2.NewWindowRequested+=delegate(object sender,CoreWebView2NewWindowRequestedEventArgs e){e.Handled=true;if(e.IsUserInitiated){Uri target;if(Uri.TryCreate(e.Uri,UriKind.Absolute,out target) && target.Scheme=="https" && target.Host=="chatgpt.com" && string.IsNullOrEmpty(target.UserInfo))new Browser(e.Uri).Show();else Go(e.Uri);}};
            web.CoreWebView2.ServerCertificateErrorDetected+=delegate(object sender,CoreWebView2ServerCertificateErrorDetectedEventArgs e){e.Action=CoreWebView2ServerCertificateErrorAction.Cancel;};
            web.CoreWebView2.PermissionRequested+=delegate(object sender,CoreWebView2PermissionRequestedEventArgs e){
                Uri site;
                if(!Uri.TryCreate(e.Uri,UriKind.Absolute,out site) || site.Scheme!="https" || !string.IsNullOrEmpty(site.UserInfo)) {
                    e.State=CoreWebView2PermissionState.Deny;e.SavesInProfile=false;return;
                }
                int kind=(int)e.PermissionKind;
                // Newer runtimes can send PersistentStorage (13) to an older SDK.
                // Storage persistence is normal site data, not access to device files.
                if(kind==13) {e.State=CoreWebView2PermissionState.Allow;e.SavesInProfile=true;return;}
                string permission=PermissionLabel(kind);
                if(permission==null || !e.IsUserInitiated) {
                    e.State=CoreWebView2PermissionState.Deny;e.SavesInProfile=false;return;
                }
                bool allowed=MessageBox.Show("Сайт "+site.GetLeftPart(UriPartial.Authority)+" запрашивает разрешение:\n"+permission+".\n\nРазрешить? Выбор будет сохранён для этого сайта.","Разрешение сайта",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes;
                e.State=allowed?CoreWebView2PermissionState.Allow:CoreWebView2PermissionState.Deny;
                e.SavesInProfile=true;
            };
            web.CoreWebView2.Settings.UserAgent += " OrbitBrowserDesktop/"+OrbitRelease.VersionText;
            SetupDownloads();
            ready=true;if(initialUrl==null)Home();else Go(initialUrl);RouteLabel();
        } catch(Exception ex) {
            status.Text="Не удалось загрузить WebView2.";
            if(MessageBox.Show("Не удалось запустить движок WebView2.\n"+ex.Message+"\n\nОткрыть официальный сайт Microsoft для установки WebView2 Runtime?","Orbit Browser",MessageBoxButtons.YesNo)==DialogResult.Yes)External("https://developer.microsoft.com/microsoft-edge/webview2/");
        }
    }
    static string PermissionLabel(int kind) {
        switch(kind) {
            case 1:return "использовать микрофон";
            case 2:return "использовать камеру";
            case 3:return "определять местоположение";
            case 4:return "показывать уведомления";
            case 5:return "использовать датчики устройства";
            case 6:return "читать буфер обмена";
            case 7:return "скачивать несколько файлов автоматически";
            case 8:return "читать и изменять выбранные файлы";
            case 9:return "автоматически воспроизводить звук и видео";
            case 10:return "использовать установленные шрифты";
            case 11:return "обмениваться системными сообщениями с MIDI-устройствами";
            case 12:return "управлять размещением окон на экранах";
            default:return null;
        }
    }
    void RouteLabel(){status.Text="Orbit · HTTPS · Готов к работе";}
    void Go(string input) {
        if(!ready){status.Text="Дождись загрузки движка.";return;}
        string value=input.Trim();if(value.Length==0)return;
        var aliases=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase) {
            {"ютуб","https://www.youtube.com/"},{"ютюб","https://www.youtube.com/"},{"youtube","https://www.youtube.com/"},
            {"тикток","https://www.tiktok.com/"},{"тик ток","https://www.tiktok.com/"},{"tiktok","https://www.tiktok.com/"},
            {"гугл","https://www.google.com/"},{"google","https://www.google.com/"},
            {"вк","https://vk.com/"},{"vk","https://vk.com/"},{"телеграм","https://web.telegram.org/"},{"telegram","https://web.telegram.org/"},
            {"чатгпт","https://chatgpt.com/"},{"chatgpt","https://chatgpt.com/"}
        };
        if(aliases.ContainsKey(value))value=aliases[value];
        if(!value.Contains("://")){
            if(System.Text.RegularExpressions.Regex.IsMatch(value,@"^(?:[\p{L}\p{N}-]+\.)+[\p{L}]{2,}(?::\d{1,5})?(?:[/?#]\S*)?$"))value="https://"+value;
            else if(System.Text.RegularExpressions.Regex.IsMatch(value,@"^[a-zA-Z][a-zA-Z0-9+.-]*:")){status.Text="Используй HTTPS-адрес.";return;}
            else {if(value.Length<2 || value.Length>300){status.Text="Введи вопрос от 2 до 300 символов.";return;}value="https://miron-browser.floot.app/?q="+Uri.EscapeDataString(value);}
        }
        Uri uri;if(!Uri.TryCreate(value,UriKind.Absolute,out uri) || uri.Scheme!="https" || string.IsNullOrEmpty(uri.Host) || !string.IsNullOrEmpty(uri.UserInfo)){status.Text="Введи HTTPS-адрес или поисковый запрос.";return;}
        web.CoreWebView2.Navigate(uri.AbsoluteUri);web.Focus();
    }
    void RestoreChrome() {
        focusView=false;
        rootLayout.RowStyles[0].Height=HeaderHeight;rootLayout.RowStyles[1].Height=NavigationHeight;rootLayout.RowStyles[2].Height=LoadingHeight;rootLayout.RowStyles[4].Height=StatusHeight;
    }
    void Home() {
        if(!ready)return;
        web.CoreWebView2.Settings.IsWebMessageEnabled=false;
        RestoreChrome();
        web.CoreWebView2.Navigate("https://miron-browser.floot.app");
    }
    void External(string url) {try {Process.Start(new ProcessStartInfo(url){UseShellExecute=true});}catch(Exception ex){MessageBox.Show(ex.Message,"Не удалось открыть ссылку");}}
    void Save(){try{File.WriteAllText(Path.Combine(data,"settings.json"),new JavaScriptSerializer().Serialize(prefs));}catch(Exception ex){MessageBox.Show(ex.Message,"Не удалось сохранить настройки");}}
    void Menu() {
        var menu=new ContextMenuStrip();
        menu.Items.Add(workHost.Panel2Collapsed?"Открыть рабочий режим · F8":"Закрыть рабочий режим · F8",null,delegate {ToggleWork();});
        menu.Items.Add("Режим фокуса · F11",null,delegate {ToggleFocus();});
        menu.Items.Add("Orbit помощник · отдельный чат",null,delegate {OpenAssistant();});
        menu.Items.Add("Сбросить решения проверок ссылок",null,delegate {riskChoices.Clear();});
        menu.Items.Add("Браузер по умолчанию…",null,delegate {OpenDefaultSettings();});
        menu.Items.Add("Загрузки",null,delegate {ShowDownloads();});
        menu.Items.Add("Проверить обновления",null,async delegate {await CheckUpdates(true);});
        menu.Items.Add("Что нового · "+OrbitRelease.VersionText,null,delegate {ShowReleaseNotes(false);});
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Аккаунт / синхронизация",null,delegate {Home();});
        menu.Items.Add("Добавить локальную закладку",null,delegate {if(ready && web.Source!=null && web.Source.Scheme=="https"){string u=web.Source.AbsoluteUri;if(!prefs.Bookmarks.Contains(u)){prefs.Bookmarks.Add(u);Save();}status.Text="Закладка сохранена.";}});
        var bookmarks=new ToolStripMenuItem("Локальные закладки");
        foreach(string url in prefs.Bookmarks){string u=url;bookmarks.DropDownItems.Add(u,null,delegate {Go(u);});}
        if(prefs.Bookmarks.Count==0)bookmarks.DropDownItems.Add("Пока пусто");menu.Items.Add(bookmarks);
        menu.Items.Add("Открыть в обычном браузере",null,delegate {if(ready && web.Source!=null && web.Source.Scheme=="https")External(web.Source.AbsoluteUri);});
        menu.Items.Add("Удалить локальные закладки",null,delegate {if(MessageBox.Show("Удалить все закладки?","Orbit Browser",MessageBoxButtons.YesNo)==DialogResult.Yes){prefs.Bookmarks.Clear();Save();}});
        menu.Items.Add("Сайт обновлений",null,delegate {Go("https://miron-browser.floot.app/updates");});
        menu.Show(Cursor.Position);
    }
    void OpenDefaultSettings() {
        try {
            var registration=Process.Start(new ProcessStartInfo("powershell.exe","-NoProfile -ExecutionPolicy Bypass -File \""+Path.Combine(Application.StartupPath,"register-browser.ps1")+"\" -AppPath \""+Application.StartupPath+"\""){UseShellExecute=false,CreateNoWindow=true});
            registration.WaitForExit();if(registration.ExitCode!=0)throw new Exception("Не удалось зарегистрировать Orbit.");
            Process.Start(new ProcessStartInfo("ms-settings:defaultapps"){UseShellExecute=true});
        }
        catch(Exception ex) {MessageBox.Show("Открой Параметры Windows → Приложения → Приложения по умолчанию.\n"+ex.Message,"Orbit Browser");}
    }
    bool ShowReleaseNotes(bool firstLaunch) {
        return OrbitDialog(firstLaunch?"Добро пожаловать в Orbit":"Orbit обновлён","Версия "+OrbitRelease.VersionText,
            "• "+string.Join("\n\n• ",OrbitRelease.Notes),"Давайте окунёмся →",false)==DialogResult.OK;
    }
    async System.Threading.Tasks.Task CheckUpdates(bool manual) {
        if(checkingUpdates)return;checkingUpdates=true;
        try {
            var release=await System.Threading.Tasks.Task.Run<ReleaseInfo>(delegate {return OrbitRelease.Download();});
            if(IsDisposed)return;
            if(!OrbitRelease.IsNewer(release)) {
                if(manual)MessageBox.Show("Установлена актуальная версия: "+OrbitRelease.VersionText,"Обновления Orbit");
                return;
            }
            status.Text="Вышла Orbit "+release.version+" · меню ⋮ → Проверить обновления";
            string noticePath=Path.Combine(data,"update-notified.txt"),notice=release.version+" "+DateTime.UtcNow.ToString("yyyy-MM-dd"),previous="";
            try {previous=File.ReadAllText(noticePath);}catch { }
            if(!manual && previous==notice)return;
            try {File.WriteAllText(noticePath,notice);}catch { }
            string message="Вышла новая версия Orbit: "+release.version+".\n\n• "+string.Join("\n• ",release.notes);
            if(string.IsNullOrEmpty(release.downloadUrl)) {
                OrbitDialog("Вышла новая версия", "Orbit "+release.version,message+"\n\nСсылка на установку пока не опубликована.","Понятно",false);
            } else if(OrbitDialog("Вышла новая версия","Orbit "+release.version,message+"\n\nСкачай обновление и установи после закрытия Orbit.","Скачать обновление",true)==DialogResult.OK)Go(release.downloadUrl);
        } catch {
            if(manual && !IsDisposed)MessageBox.Show("Список версий пока недоступен. Проверь подключение или попробуй позже.","Обновления Orbit",MessageBoxButtons.OK,MessageBoxIcon.Information);
        } finally {checkingUpdates=false;}
    }
}
