param([string]$AppPath = $PSScriptRoot)
$ErrorActionPreference = 'Stop'
$exePath = Join-Path $AppPath 'OrbitBrowser.exe'
if (!(Test-Path -LiteralPath $exePath)) { throw 'OrbitBrowser.exe not found. Install Orbit first.' }
$command = '"' + $exePath + '" "%1"'
$icon = '"' + $exePath + '",0'
function Set-OrbitValue([string]$Path,[string]$Name,[string]$Value) {
    $key = [Microsoft.Win32.Registry]::CurrentUser.CreateSubKey($Path)
    try { $key.SetValue($Name,$Value,[Microsoft.Win32.RegistryValueKind]::String) } finally { $key.Dispose() }
}
$progId = 'Software\Classes\OrbitBrowser.Url'
Set-OrbitValue $progId '' 'Orbit Browser URL'
Set-OrbitValue $progId 'URL Protocol' ''
Set-OrbitValue $progId 'FriendlyTypeName' 'Orbit Browser'
Set-OrbitValue "$progId\DefaultIcon" '' $icon
Set-OrbitValue "$progId\shell\open\command" '' $command
$client = 'Software\Clients\StartMenuInternet\OrbitBrowser'
Set-OrbitValue $client '' 'Orbit Browser'
Set-OrbitValue "$client\DefaultIcon" '' $icon
Set-OrbitValue "$client\shell\open\command" '' ('"' + $exePath + '"')
$capabilities = "$client\Capabilities"
Set-OrbitValue $capabilities 'ApplicationName' 'Orbit Browser'
Set-OrbitValue $capabilities 'ApplicationDescription' 'Orbit Browser - browse HTTPS sites with your Orbit account.'
Set-OrbitValue $capabilities 'ApplicationIcon' $icon
Set-OrbitValue "$capabilities\URLAssociations" 'https' 'OrbitBrowser.Url'
Set-OrbitValue "$capabilities\URLAssociations" 'http' 'OrbitBrowser.Url'
Set-OrbitValue "$capabilities\Startmenu" 'StartMenuInternet' 'OrbitBrowser'
Set-OrbitValue 'Software\RegisteredApplications' 'Orbit Browser' $capabilities
# Advertise support only. Windows owns UserChoice and the final default selection.
if (-not ('OrbitShellNotify' -as [type])) {
    Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public static class OrbitShellNotify { [DllImport("shell32.dll")] public static extern void SHChangeNotify(uint eventId,uint flags,IntPtr first,IntPtr second); }'
}
[OrbitShellNotify]::SHChangeNotify(0x08000000,0x1000,[IntPtr]::Zero,[IntPtr]::Zero)
Write-Host 'Orbit Browser registered. Choose it in Windows Default apps.'
