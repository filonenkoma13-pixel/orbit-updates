using System;
using System.IO;
using System.Drawing;
using System.Windows.Forms;
using System.Diagnostics;
using System.Collections.Generic;
using Microsoft.Web.WebView2.Core;

partial class Browser {
    readonly List<OrbitDownload> downloads=new List<OrbitDownload>();
    Form downloadsWindow; ListBox downloadsList;
    sealed class OrbitDownload {
        public CoreWebView2DownloadOperation Operation;
        public string Path;
        public override string ToString(){
            string state=Operation.State==CoreWebView2DownloadState.Completed?"Готово":Operation.State==CoreWebView2DownloadState.Interrupted?"Остановлено: "+Operation.InterruptReason:"Скачивается";
            return System.IO.Path.GetFileName(Path)+" · "+state+" · "+(Operation.BytesReceived/1048576.0).ToString("0.0")+" МБ";
        }
    }
    void SetupDownloads(){
        web.CoreWebView2.DownloadStarting+=delegate(object sender,CoreWebView2DownloadStartingEventArgs e){
            var deferral=e.GetDeferral(); e.Handled=true;
            BeginInvoke((Action)delegate {
                try {
                    if(IsDisposed){e.Cancel=true;return;}
                    string filename=Path.GetFileName(e.ResultFilePath);
                    if(string.IsNullOrWhiteSpace(filename))filename="download";
                    using(var dialog=new SaveFileDialog {Title="Orbit · Сохранить файл",FileName=filename,Filter="Все файлы (*.*)|*.*",OverwritePrompt=true,RestoreDirectory=true}){
                        string folder=Path.GetDirectoryName(e.ResultFilePath);
                        if(!string.IsNullOrEmpty(folder)&&Directory.Exists(folder))dialog.InitialDirectory=folder;
                        if(dialog.ShowDialog(this)!=DialogResult.OK){e.Cancel=true;return;}
                        e.ResultFilePath=Path.GetFullPath(dialog.FileName);
                    }
                    var item=new OrbitDownload {Operation=e.DownloadOperation,Path=e.ResultFilePath};downloads.Add(item);
                    item.Operation.BytesReceivedChanged+=delegate {RefreshDownloads();};
                    item.Operation.StateChanged+=delegate {
                        if(IsDisposed)return;
                        if(item.Operation.State==CoreWebView2DownloadState.Completed)status.Text="Скачано: "+Path.GetFileName(item.Path);
                        else if(item.Operation.State==CoreWebView2DownloadState.Interrupted)status.Text="Загрузка остановлена: "+item.Operation.InterruptReason+" · меню → Загрузки";
                        RefreshDownloads();
                    };
                    status.Text="Скачивается: "+filename;
                    ShowDownloads();
                }catch(Exception ex){e.Cancel=true;if(!IsDisposed)MessageBox.Show(ex.Message,"Не удалось начать загрузку");}
                finally {deferral.Complete();}
            });
        };
    }
    void RefreshDownloads(){
        if(IsDisposed||downloadsList==null||downloadsList.IsDisposed)return;
        int selected=downloadsList.SelectedIndex;downloadsList.BeginUpdate();downloadsList.Items.Clear();
        foreach(var item in downloads)downloadsList.Items.Add(item);
        if(selected>=0&&selected<downloadsList.Items.Count)downloadsList.SelectedIndex=selected;
        downloadsList.EndUpdate();
    }
    OrbitDownload SelectedDownload(){return downloadsList==null?null:downloadsList.SelectedItem as OrbitDownload;}
    void ShowDownloads(){
        if(downloadsWindow!=null&&!downloadsWindow.IsDisposed){RefreshDownloads();downloadsWindow.Show();downloadsWindow.Activate();return;}
        downloadsWindow=new Form {Text="Orbit · Загрузки",Width=760,Height=440,MinimumSize=new Size(520,300),BackColor=background,ForeColor=Color.White,StartPosition=FormStartPosition.CenterParent,Font=new Font("Segoe UI",10)};
        var layout=new TableLayoutPanel {Dock=DockStyle.Fill,RowCount=3,ColumnCount=1,Padding=new Padding(16)};
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute,35));layout.RowStyles.Add(new RowStyle(SizeType.Percent,100));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,48));
        layout.Controls.Add(new Label {Text="Загрузки текущего окна · файлы остаются на компьютере",Dock=DockStyle.Fill,ForeColor=accent},0,0);
        downloadsList=new ListBox {Dock=DockStyle.Fill,BackColor=background,ForeColor=Color.White,BorderStyle=BorderStyle.FixedSingle,HorizontalScrollbar=true};layout.Controls.Add(downloadsList,0,1);
        var actions=new FlowLayoutPanel {Dock=DockStyle.Fill,WrapContents=true};
        Action<string,Action> add=delegate(string label,Action action){var b=new Button {Text=label,AutoSize=true,Height=34,FlatStyle=FlatStyle.Flat,BackColor=background,ForeColor=accent};b.Click+=delegate {try{action();}catch(Exception ex){MessageBox.Show(ex.Message,"Загрузки Orbit");}};actions.Controls.Add(b);};
        add("Папка",delegate {var d=SelectedDownload();if(d!=null)Process.Start(new ProcessStartInfo("explorer.exe","/select,\""+d.Path+"\""){UseShellExecute=true});});
        add("Продолжить",delegate {var d=SelectedDownload();if(d!=null&&d.Operation.CanResume)d.Operation.Resume();});
        add("Отменить",delegate {var d=SelectedDownload();if(d!=null&&d.Operation.State!=CoreWebView2DownloadState.Completed)d.Operation.Cancel();});
        add("Причина сбоя",delegate {var d=SelectedDownload();if(d==null)return;string reason=d.Operation.State==CoreWebView2DownloadState.Interrupted?d.Operation.InterruptReason.ToString():d.Operation.State.ToString();MessageBox.Show("Файл: "+Path.GetFileName(d.Path)+"\n\nСостояние: "+reason+"\n\n"+DownloadExplanation(reason),"Загрузка Orbit");});
        layout.Controls.Add(actions,0,2);downloadsWindow.Controls.Add(layout);downloadsWindow.FormClosed+=delegate {downloadsList=null;};RefreshDownloads();downloadsWindow.Show(this);
    }
    static string DownloadExplanation(string reason){
        if(reason.StartsWith("Network"))return "Соединение с сервером файла прервалось. Проверь этот же файл в другом браузере без VPN; код ошибки поможет отличить сеть от ошибки Orbit.";
        if(reason=="FileAccessDenied")return "Windows не разрешила запись в выбранную папку. Выбери другую папку для загрузки.";
        if(reason=="FileNoSpace")return "На диске не хватает свободного места.";
        if(reason=="FileBlockedByPolicy"||reason=="FileMalicious"||reason=="FileSecurityCheckFailed")return "Скачивание остановлено проверкой безопасности или правилом Windows. Orbit не отключает эту проверку.";
        if(reason.StartsWith("Server"))return "Сервер файла отклонил запрос или вернул ошибку. Это ответ сервера, а не сообщение о необходимости VPN.";
        if(reason.StartsWith("User"))return "Скачивание остановлено или приостановлено пользователем либо закрытием окна.";
        return "Пришли этот код ошибки, если файл не скачивается.";
    }
}
