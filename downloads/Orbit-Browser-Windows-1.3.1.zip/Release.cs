﻿using System;
using System.IO;
using System.Net;
using System.Text;
using System.Reflection;
using System.Web.Script.Serialization;

[assembly: AssemblyVersion("1.3.1.0")]
[assembly: AssemblyFileVersion("1.3.1.0")]

static class OrbitRelease {
    public const string VersionText="1.3.1";
    public const string FeedUrl="https://miron-browser.floot.app/orbit-windows-release.json";
    public static readonly string[] Notes={
        "Добавлено окно загрузок: выбор папки, прогресс и продолжение скачивания.",
        "При сбое отображается точная причина от движка браузера.",
        "Обновление Orbit скачивается через тот же менеджер загрузок."
    };
    public static ReleaseInfo Download() {
        ServicePointManager.SecurityProtocol=SecurityProtocolType.Tls12;
        var request=(HttpWebRequest)WebRequest.Create(FeedUrl);
        request.Timeout=8000;request.ReadWriteTimeout=8000;request.AllowAutoRedirect=false;
        request.Accept="application/json";request.UserAgent="OrbitBrowserDesktop/"+VersionText;
        using(var response=(HttpWebResponse)request.GetResponse()) {
            if(response.StatusCode!=HttpStatusCode.OK || response.ContentLength>65536 ||
                !response.ContentType.StartsWith("application/json",StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("Invalid release response");
            using(var stream=response.GetResponseStream())
            using(var data=new MemoryStream()) {
                var buffer=new byte[4096];int count;
                while((count=stream.Read(buffer,0,buffer.Length))>0) {
                    if(data.Length+count>65536)throw new InvalidDataException("Release response too large");
                    data.Write(buffer,0,count);
                }
                var serializer=new JavaScriptSerializer {MaxJsonLength=65536,RecursionLimit=8};
                return Validate(serializer.Deserialize<ReleaseInfo>(Encoding.UTF8.GetString(data.ToArray())));
            }
        }
    }
    public static ReleaseInfo Validate(ReleaseInfo release) {
        Version version;
        if(release==null || release.platform!="windows" || release.version==null || release.version.Length>32 ||
            !Version.TryParse(release.version,out version))throw new InvalidDataException("Invalid release version");
        if(release.notes==null)release.notes=new string[0];
        if(release.notes.Length>12)throw new InvalidDataException("Too many release notes");
        foreach(var note in release.notes)if(note==null || note.Length>400)throw new InvalidDataException("Invalid release note");
        if(!string.IsNullOrEmpty(release.downloadUrl)) {
            Uri url;
            if(release.downloadUrl.Length>2048 || !Uri.TryCreate(release.downloadUrl,UriKind.Absolute,out url) ||
                url.Scheme!="https" || string.IsNullOrEmpty(url.Host) || !string.IsNullOrEmpty(url.UserInfo))
                throw new InvalidDataException("Invalid download URL");
        }
        return release;
    }
    public static bool IsNewer(ReleaseInfo release) {
        var remote=new Version(release.version);var local=new Version(VersionText);
        remote=new Version(remote.Major,remote.Minor,Math.Max(0,remote.Build),Math.Max(0,remote.Revision));
        local=new Version(local.Major,local.Minor,Math.Max(0,local.Build),Math.Max(0,local.Revision));
        return remote>local;
    }
}
class ReleaseInfo {
    public string platform {get;set;}
    public string version {get;set;}
    public string downloadUrl {get;set;}
    public string[] notes {get;set;}
}

static class OrbitAddress {
    public static string NormalizeLaunchUrl(string input) {
        Uri url;
        if(string.IsNullOrWhiteSpace(input) || input.Length>8192 || !Uri.TryCreate(input,UriKind.Absolute,out url) ||
            (url.Scheme!="https" && url.Scheme!="http") || string.IsNullOrEmpty(url.Host) || !string.IsNullOrEmpty(url.UserInfo))return null;
        if(url.Scheme=="http") {
            var upgraded=new UriBuilder(url);upgraded.Scheme="https";if(url.IsDefaultPort)upgraded.Port=-1;
            url=upgraded.Uri;
        }
        return url.AbsoluteUri;
    }
}
